World of Warcraft addon that generates 10-man raid groups

Edit the RaidGenerator.lua to change members.

Use /rg or /raidgenerate command in-game to generate new list.
By default the output will be printed to guild.