-- RaidGenerator

SLASH_RAIDGENERATOR1 = "/rg";
SLASH_RAIDGENERATOR2 = "/raidgenerate";

groups = 2;
tanksPerGroup = 2;
healsPerGroup = 3;
dpsPerGroup = 5;

function resetMembers()
	tanks = {
		"Elye",
		"Muonamestari",
	   "Rytmiliieri",
	   "Jenkkis"
	}
	
	healers = {
	   "Maitoparta",
	   "Tiwwue",
	   "Kilrain",
	   "Tawi",
	   "Belvain"
	}
	
	dps = {
		"Xanabless",
	   "Loreina",
	   "Munalukko",
	   "Merome",
	   "Palkka",
	   "Vaarala",
	   "Morkkeli",
	   "Vatipaa",
	   "Juopox",
	   "Rofloller",
	   "Jeazy"
	}
end

if not RGFrame then
	RGFrame = CreateFrame("Frame", "RGFrame");
end

RGFrame:SetScript("OnEvent", function(self, event, ...) 
	if event == "VARIABLES_LOADED" then
		SlashCmdList["RAIDGENERATOR"] = function(msg)
			RaidGenerator_SlashCommandHandler(msg);
		end
		resetMembers();
	end
end)

function RaidGenerator_SlashCommandHandler(msg)	
	if (msg == "") then
		makeGroups();
	else
		print("RaidGen: " .. msg);
	end
end

function makeGroups()
	resetMembers();
	
	local i = 1;
	while i <= groups do		
		local tanklist = "";
		local j = 1;
		-- Randomize tanks
		while j <= tanksPerGroup do
			k = getn(tanks);
			if (k <= 0) then break;
			end
			
			local num = math.random(k);
			tanklist = tanklist .. tanks[num] .. ", " ;
			table.remove(tanks, num);
			j = j + 1;
		end
		
		local healerlist = "";
		local j = 1;
		-- Randomize healers
		while j <= healsPerGroup do
			k = getn(healers);
			if (k <= 0) then break;
			end
			
			local num = math.random(k);
			healerlist = healerlist .. healers[num] .. ", ";
			table.remove(healers, num);
			j = j + 1;
		end
		
		local dpslist = "";
		local j = 1;
		-- Randomize dps
		while j <= dpsPerGroup do
			k = getn(dps);
			if (k <= 0) then break;
			end
			
			local num = math.random(k);
			dpslist = dpslist .. dps[num] .. ", " ;
			table.remove(dps, num);
			j = j + 1;
		end
		
		-- Send to guild chat
		SendChatMessage("Group " .. i, "GUILD", nil, "");
		SendChatMessage("  Tankit: " .. tanklist, "GUILD", nil, "");
		SendChatMessage("  Healerit: " .. healerlist, "GUILD", nil, "");
		SendChatMessage("  Depsit: " .. dpslist, "GUILD", nil, "");
		
		i = i + 1;
	end
end

RGFrame:RegisterEvent("VARIABLES_LOADED");










