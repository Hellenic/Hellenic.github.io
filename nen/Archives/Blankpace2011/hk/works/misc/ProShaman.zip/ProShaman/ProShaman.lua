-- ProShaman
--		Addon for shields, Maelstrom weapon and weapon buff alerts
--		Add groundings
-- by Hannu K�rkk�inen

SLASH_PROSHAMAN1 = "/proshaman";
SLASH_PROSHAMAN2 = "/ps";
LastUpdate = 0;
mbFading = 0;

-- If class isn't shaman, disable this addon
if select(2, UnitClass('player')) ~= "SHAMAN" then
	DisableAddOn("ProShaman")
	return
end

-- Initializing... Create frame
if not PSFrame then
	PSFrame = CreateFrame("Frame", "PSFrame");
end


PSFrame:SetScript("OnEvent", function(self, event, ...) 
	if event == "VARIABLES_LOADED" then
		ProShaman_Init();
	
	elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
		local _, evt, _, source = ...;
		
		if (evt == "SPELL_INTERRUPT" and source == UnitName("player")) then
			local spellInterrupted = select(13, ...);
			UIErrorsFrame:AddMessage("Interrupted: "..spellInterrupted, 1.0, 1.0, 0.4, 53, 5);
			
		elseif (evt == "SPELL_DISPEL" and source == UnitName("player")) then
			local spellName = select(10, ...);
			local purgedBuff = select(13, ...);
			
			if (spellName == "Purge") then
				UIErrorsFrame:AddMessage("Purged: "..purgedBuff, 1.0, 1.0, 0.4, 53, 5);
			end
			
		elseif (evt == "UNIT_SPELLCAST_FAILED_QUIET") then
			UIErrorsFrame:AddMessage("UNIT_SPELLCAST_FAILED_QUIET");
		elseif (evt == "UNIT_SPELLCAST_SUCCEEDED") then
			UIErrorsFrame:AddMessage("UNIT_SPELLCAST_SUCCEEDED");
		
		end

	--elseif event == "PLAYER_REGEN_ENABLED" then
		-- Fix the shitty pet bar
	--	PetActionBarFrame.locked = false;
	--	PetActionBarFrame:Show()
	--	PetActionBarFrame.locked = true;

	elseif event == "PLAYER_REGEN_DISABLED" then
		local main, maintime, _, off, offtime, _ = GetWeaponEnchantInfo();
		
		if (main == 1 and off == 1) then
			--print("ProShaman: Weapon buffs ON!");
		else
			UIErrorsFrame:AddMessage("Weapon buffs MISSING!", 1.0, 0.0, 0.0, 53, 5);
			PlaySoundFile("Sound\\Doodad\\BellowIn.wav");
		end
	end
end)



-- Initializing... Create bar frames
function ProShaman_Init()
	-- Backdrop
	local ProShamanBG = {
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", 
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", 
		tile = false,
		tileSize = 1,
		edgeSize = 15,
		insets = {
			left = 3,
			right = 3,
			top = 3,
			bottom = 3
		}
	};
	
	-- Shield status bar
	sbf = CreateFrame("Frame", nil, UIParent);
	sbf:SetWidth(260);
	sbf:SetHeight(30);
	sbf:SetPoint("CENTER", 0, -185);
	
	sbf:SetBackdrop(ProShamanBG);
	sbf:SetBackdropBorderColor(0.2, 0.2, 0.2);
	sbf:SetBackdropColor(1.0, 1.0, 1.0, 0.8);
	
	sb = CreateFrame("StatusBar", nil, sbf, "TextStatusBar");
	sb:SetWidth(250);
	sb:SetHeight(20);
	sb:SetPoint("CENTER", sbf);
	sb:SetStatusBarTexture("Interface\\Tooltips\\UI-Tooltip-Background");
	sb:SetStatusBarColor(0.1, 0.1, 1.0, 0.8);
	sb:SetMinMaxValues(0, 600); -- 0 to 10min
	sb:SetValue(200);
	
	sbtxt = sb:CreateFontString("SBarText", "Artwork", "GameFontNormal");
	sbtxt:SetAllPoints();
	sbtxt:SetTextColor(1.0, 1.0, 1.0, 1.0);
	sbtxt:SetText("Shields");


	-- Maelstrom status bar
	mbf = CreateFrame("Frame", nil, UIParent);
	mbf:SetWidth(260);
	mbf:SetHeight(30);
	mbf:SetPoint("CENTER", 0, -160);
	
	mbf:SetBackdrop(ProShamanBG);
	mbf:SetBackdropBorderColor(0.2, 0.2, 0.2);
	mbf:SetBackdropColor(1.0, 1.0, 1.0, 0.8);
	
	mb = CreateFrame("StatusBar", nil, mbf, "TextStatusBar");
	mb:SetWidth(250);
	mb:SetHeight(20);
	mb:SetPoint("CENTER", mbf);
	mb:SetStatusBarTexture("Interface\\Tooltips\\UI-Tooltip-Background");
	mb:SetStatusBarColor(0.5, 0.0, 0.9, 0.8);
	mb:SetMinMaxValues(0, 30);
	mb:SetValue(10);
	
	mbtxt = mb:CreateFontString("MBarText", "Artwork", "GameFontNormal");
	mbtxt:SetAllPoints();
	mbtxt:SetTextColor(1.0, 1.0, 1.0, 1.0);
	mbtxt:SetText("Maelstrom Weapon");
	
	-- OnUpdate for ShieldBar, will also update Maelstrom Bar
	sb:SetScript("OnUpdate", function(self, elapsed)
		LastUpdate = LastUpdate + elapsed; 	
		
		if (LastUpdate > 0.1) then
			ProShaman_SetShieldInfo();
			LastUpdate = 0;
		end
	end)

	SlashCmdList["PROSHAMAN"] = function(msg)
		ProShaman_SlashCommandHandler(msg);
	end
	
	-- Fix the shitty pet bar here too, so it shows when you enter the battle for the first time too
	--PetActionBarFrame.locked = false;
	--PetActionBarFrame:Show()
	--PetActionBarFrame.locked = true;
	
	print("ProShaman loaded!");
end

-- /slash command handler
function ProShaman_SlashCommandHandler(msg)	
	if (msg == "0") then
		ReloadUI();
	else
		print("ProShaman: " .. msg);
	end
end

-- Check buffs
function ProShaman_SetShieldInfo()
	local index = 1
	local shield = 0
	local maelstrom = 0

	while UnitBuff("Player", index) do
		local name, _, _, count, _, duration, expires = UnitBuff("Player", index)
		
		if name == "Water Shield" then
			sb:SetStatusBarColor(0.55, 0.55, 1.0, 0.8);
			sbtxt:SetText(count .. "   " .. name);
			sb:SetValue(expires-GetTime());
			
			if count == 1 then
				sb:SetStatusBarColor(1.0, 0.3, 0.5, 0.8);	
			end
			
			shield = 1;
			
			
		elseif name == "Lightning Shield" then
			sb:SetStatusBarColor(0.2, 0.2, 1.0, 0.8);
			sbtxt:SetText(count .. "   " .. name);
			sb:SetValue(expires-GetTime());
			
			if count == 1 then
				sb:SetStatusBarColor(1.0, 0.3, 0.5, 0.8);	
			end
			
			shield = 1;
			
			
		elseif name == "Earth Shield" then
			sb:SetStatusBarColor(0.9, 0.8, 0.0, 0.8);
			sbtxt:SetText(count .. "   " .. name);
			sb:SetValue(expires-GetTime());
			
			if count == 1 then
				sb:SetStatusBarColor(1.0, 0.6, 0.4, 0.8);	
			end
			
			shield = 1;
			
			
		elseif name == "Maelstrom Weapon" then
			mbtxt:SetText(count .. "   " .. name);
			mb:SetValue(expires-GetTime());
			maelstrom = 1;
			
			if (count == 5) then
				if (mbFading == 1) then
					local alp = mb:GetAlpha() - 0.2;
					mb:SetAlpha(alp);
					
					if (alp < 0.2) then
						mbFading = 0;
					end
				else
					local alp = mb:GetAlpha() + 0.2;
					mb:SetAlpha(alp);
					
					if (alp > 0.8) then
						mbFading = 1;
					end
				end
			else
				mb:SetAlpha(0.8);
			end
			
		end
			
		index = index + 1
	end
	
	if shield == 0 then
		sbtxt:SetText("No shield active!");
		sb:SetStatusBarColor(1.0, 0.1, 0.1, 0.8);	
		sb:SetValue(600);
	end
	
	if maelstrom == 0 then
		mbtxt:SetText("No maelstrom stacks!");
		mb:SetValue(0);
		mbf:Hide();
	else
		mbf:Show();
	end
end


PSFrame:RegisterEvent("VARIABLES_LOADED");
PSFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
PSFrame:RegisterEvent("PLAYER_REGEN_ENABLED");
PSFrame:RegisterEvent("PLAYER_REGEN_DISABLED");